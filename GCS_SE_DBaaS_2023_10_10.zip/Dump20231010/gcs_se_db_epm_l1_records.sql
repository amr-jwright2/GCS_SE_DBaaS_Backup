CREATE DATABASE  IF NOT EXISTS `gcs_se_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci */;
USE `gcs_se_db`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: maria3264-lb-lc-in.iglb.intel.com    Database: gcs_se_db
-- ------------------------------------------------------
-- Server version	5.5.5-10.6.11-MariaDB-1:10.6.11+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `epm_l1_records`
--

DROP TABLE IF EXISTS `epm_l1_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `epm_l1_records` (
  `epm_l1_id` int(10) unsigned NOT NULL,
  `epm_l1_name` varchar(255) NOT NULL,
  PRIMARY KEY (`epm_l1_id`),
  UNIQUE KEY `level_1_epm_id_UNIQUE` (`epm_l1_id`),
  UNIQUE KEY `level_1_Name_UNIQUE` (`epm_l1_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `epm_l1_records`
--

LOCK TABLES `epm_l1_records` WRITE;
/*!40000 ALTER TABLE `epm_l1_records` DISABLE KEYS */;
INSERT INTO `epm_l1_records` VALUES (232647,'ASICs'),(78586,'Boards and Kits'),(53,'Chipsets'),(96622,'Connectivity Products'),(100011,'Drones'),(82096,'Education'),(85216,'Emerging Technologies'),(36773,'Ethernet Products'),(70021,'Fabric Products'),(80939,'Graphics'),(3110,'I/O Products'),(98836,'Intel® FPGAs'),(98414,'Intel® NUC'),(35125,'Memory and Storage'),(59483,'Mobile Communications Products'),(132209,'Partnered Products'),(873,'Processors'),(69636,'Programs'),(1201,'Server Products'),(75319,'Services'),(69130,'Smart and Connected Home'),(67709,'Software'),(77353,'Software Development Platform'),(2526,'Support'),(81240,'Technologies'),(59485,'Wireless');
/*!40000 ALTER TABLE `epm_l1_records` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-10 13:55:20
