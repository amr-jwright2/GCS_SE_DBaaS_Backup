CREATE DATABASE  IF NOT EXISTS `gcs_se_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci */;
USE `gcs_se_db`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: maria3264-lb-lc-in.iglb.intel.com    Database: gcs_se_db
-- ------------------------------------------------------
-- Server version	5.5.5-10.6.11-MariaDB-1:10.6.11+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `remote_lab_suts`
--

DROP TABLE IF EXISTS `remote_lab_suts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remote_lab_suts` (
  `idRemote_Lab_SUTs` int(11) NOT NULL AUTO_INCREMENT,
  `labLocation` varchar(45) NOT NULL,
  `kvmName` varchar(45) NOT NULL,
  `portNumber` smallint(5) unsigned NOT NULL,
  `sutName` varchar(45) NOT NULL,
  `sutMake` varchar(45) NOT NULL,
  `sutModel` varchar(45) NOT NULL,
  `sutCodeName` varchar(45) NOT NULL,
  PRIMARY KEY (`idRemote_Lab_SUTs`),
  UNIQUE KEY `idRemote_Lab_SUTs_UNIQUE` (`idRemote_Lab_SUTs`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remote_lab_suts`
--

LOCK TABLES `remote_lab_suts` WRITE;
/*!40000 ALTER TABLE `remote_lab_suts` DISABLE KEYS */;
INSERT INTO `remote_lab_suts` VALUES (1,'or','or-gcs-kx3-1-kvm',1,'HF101 BNUC11TNKv70000(Tiger Canyon vPRO)','Intel','NUC11TNKv7','Tiger Canyon'),(2,'or','or-gcs-kx3-1-kvm',2,'HF103 CMCR1AB(Icon Bay)','Intel','',''),(3,'or','or-gcs-kx3-1-kvm',3,'HF103 CMCR1AB(Elk Bay)','Intel','CMCR1AB','Elk Bay'),(4,'or','or-gcs-kx3-1-kvm',4,'HF104 SWNUC11PAHi7000(Panther Canyon)','Intel','NUC11PAHi7','Panther Canyon'),(5,'or','or-gcs-kx3-1-kvm',5,'HF105 RNUC12WSHi7000(WallstreetCanyon)','Intel','NUC12WSHi7','Wallstreet Canyon'),(6,'or','or-gcs-kx3-1-kvm',6,'HF106 BXNUC10i7FNK2(Frost Canyon)','Intel','NUC10i7FNK','Frost Canyon'),(7,'or','or-gcs-kx3-1-kvm',7,'HF107 NUC11ATKC4(Atlas Canyon)','Intel','NUC11ATKC4','Atlas Canyon'),(8,'or','or-gcs-kx3-1-kvm',8,'HF108 BLKNUC7i7DNK1E(Dawson Canyon)','Intel','NUC7i7DNK','Dawson Canyon'),(9,'or','or-gcs-kx3-1-kvm',9,'HF109 BXNUC10i5FNHJA1(Frost Canyon)','Intel','NUC10i5FNH','Frost Canyon'),(10,'or','or-gcs-kx3-1-kvm',10,'HF110 BOXNUC8i5BEKPA(Bean Canyon)','Intel','NUC8i5BEK','Bean Canyon'),(11,'or','or-gcs-kx3-1-kvm',11,'HF111 BKNUC8CCHKR1(Chaco Canyon)','Intel','NUC8CCHKR','Chaco Canyon'),(12,'or','or-gcs-kx3-1-kvm',12,'HF112 NUC8v5PNK(Provo Canyon)','Intel','NUC8v5PNK','Provo Canyon'),(13,'or','or-gcs-kx3-1-kvm',13,'HF113 BOXNUC7CJYSAL(June Canyon)','Intel','NUC7CJYSAL','June Canyon'),(14,'or','or-gcs-kx3-1-kvm',14,'','Intel','',''),(15,'or','or-gcs-kx3-1-kvm',15,'HF115 SWNUC11PHKi7CAM(Phanton Canyon)','Intel','NUC11PHKi7','Panther Canyon'),(16,'or','or-gcs-kx3-1-kvm',16,'HF116 BOXNUC8i7HNK1(Hades Canyon)','Intel','NUC8i7HNK','Hades Canyon'),(17,'or','or-gcs-kx3-1-kvm',17,'HF117 BNUC12DCMv9(Dragon Canyon #1 vPRO)','Intel','NUC12DCMv9','Dragon Canyon'),(18,'or','or-gcs-kx3-1-kvm',18,'HF118 NUC13VYKi7(Vivid Canyon)','Intel','NUC12DCMv9','Dragon Canyon'),(19,'or','or-gcs-kx3-1-kvm',19,'HF119 RNUC11BTMi90000(Beast Canyon)','Intel','NUC11BTMi9','Beast Canyon'),(20,'or','or-gcs-kx3-1-kvm',20,'HF120 PNUC13RNGi90000(Raptor Canyon)','Intel','NUC13RNGi9','Raptor Canyon'),(21,'or','or-gcs-kx3-1-kvm',21,'HF121 BKNUC9VXQNX(Quartz Canyon)','Intel','NUC9VXQNX','Quartz Canyon'),(22,'or','or-gcs-kx3-1-kvm',22,'HF122 NUC12SNKi7(Serpent Canyon)','Intel','NUC12SNKi7','Serpent Canyon'),(25,'or','or-gcs-kx3-1-kvm',25,'BRC710ECUXBD1','Intel','BRC710ECUXBD1','Rooks County'),(26,'or','or-gcs-kx3-1-kvm',23,'HF123 NUC7i5BN(Baby Canyon)','Intel','NUC7i5BN','Baby Canyon');
/*!40000 ALTER TABLE `remote_lab_suts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-10 13:56:02
