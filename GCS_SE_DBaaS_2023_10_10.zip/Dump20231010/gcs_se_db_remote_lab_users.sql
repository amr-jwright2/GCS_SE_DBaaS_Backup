CREATE DATABASE  IF NOT EXISTS `gcs_se_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci */;
USE `gcs_se_db`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: maria3264-lb-lc-in.iglb.intel.com    Database: gcs_se_db
-- ------------------------------------------------------
-- Server version	5.5.5-10.6.11-MariaDB-1:10.6.11+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `remote_lab_users`
--

DROP TABLE IF EXISTS `remote_lab_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remote_lab_users` (
  `idRemote_Lab_Users` int(11) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(45) NOT NULL,
  `idsid` varchar(45) NOT NULL,
  `wwid` varchar(45) DEFAULT NULL,
  `emailAddress` varchar(45) DEFAULT NULL,
  `userGroup` smallint(6) NOT NULL,
  `archive` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idRemote_Lab_Users`),
  UNIQUE KEY `ï»¿idRemote_Lab_Users_UNIQUE` (`idRemote_Lab_Users`),
  UNIQUE KEY `idsid_UNIQUE` (`idsid`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remote_lab_users`
--

LOCK TABLES `remote_lab_users` WRITE;
/*!40000 ALTER TABLE `remote_lab_users` DISABLE KEYS */;
INSERT INTO `remote_lab_users` VALUES (1,'Admin','admin','0','0',1,0),(2,'Adrian Jimenez','adrianji','12069186','adrian.jimenez@intel.com',3,0),(3,'Stan Chang','changsta','11996556','stan.chang@intel.com',5,0),(4,'Chong Tong','chongton','12077008','chong.tong@intel.com',8,0),(5,'Chris Varekamp','cnvareka','11495257','chris.n.varekamp@intel.com',4,0),(6,'Daniel Fuentes Farrulla','dafuent','11278500','daniel.fuentes.farrulla@intel.com',10,0),(7,'David Chuang','dchuang','12079326','david.chuang@intel.com',5,0),(8,'Emil Chen','emilchen','11448502','emil.chen@intel.com',5,0),(9,'Esteban Ramirez Gutierrez','esteban2','11346041','esteban.ramirez.gutierrez@intel.com',8,0),(10,'Gfx Guest Account','gfx_guest','1','1',8,0),(11,'Gilbert Kao','gkao','11870542','gilbert.kao@intel.com',5,0),(12,'Howard Chang','hchang4x','11956112','howardx.chang@intel.com',5,0),(13,'Chi-en Ho','hochien','11926826','chi-en.ho@intel.com',5,0),(14,'Ilya Vorobyev','ivorobye','11931819','ilya.vorobyev@intel.com',7,0),(15,'Joseph Bayless','jbayless','12058407','joseph.bayless@intel.com',8,0),(16,'Jeff Brothers','jbrother','10696353','jeff.brothers@intel.com',4,0),(17,'Jack Chang','jchan11','11339926','jack.chang@intel.com',5,0),(18,'James Chuang','jchuang','11336314','james.chuang@intel.com',5,0),(19,'Jason He','jhe4','10710486','jason.j.he@intel.com',10,0),(20,'Jack Hung','jhung','11491920','jack.hung@intel.com',5,0),(21,'Jimmy Jiang','jimmyjia','11858597','jimmy1.jiang@intel.com',5,0),(22,'John Sissell','jsissell','10645510','john.sissell@intel.com',8,0),(23,'Justin Wright','jwright2','10631634','justin.l.wright@intel.com',4,0),(24,'Karthi Jaganathan','kjagan','10583499','karthi.jaganathan@intel.com',4,0),(25,'Kamal Lee','klee38','10715395','kamal.lee@intel.com',5,0),(26,'Kishore Vetuir','kveturi','11102451','kishore.veturi@intel.com',10,0),(27,'Larissa Hsu','larissah','12061132','larissa.hsu@intel.com',5,0),(28,'Lex Hung','lexhung','12106862','lex.hung@intel.com',5,0),(29,'Luis Cordoba Morales','lfcordob','12089015','luis.cordoba.morales@intel.com',8,0),(30,'Maria Ramirez','mframire','11907636','maria.ramirez.valverde@intel.com',3,0),(31,'Muji Muhammad','mmujeeb','12094413','muhammad.mujeeb@intel.com',8,0),(32,'Maria Oleneva','moleneva','11736788','maria.oleneva@intel.com',3,0),(33,'Gabriela Estrada','munozgab','11715679','gabriela.estrada@intel.com',8,0),(34,'PoChing Lee','pochingl','11989224','poching.lee@intel.com',5,0),(35,'Quin Chou','qchou','11843483','quin.chou@intel.com',5,0),(36,'Ravikumar B.S','rbs','10691600','ravikumar.b.s@intel.com',3,0),(37,'Ronny Guevara','rguevara','11087734','ronny.guevara@intel.com',3,0),(38,'Ronald Morera Rodriguez','rmorera','11388220','ronald.morera@intel.com',7,0),(39,'Ronald Cheng','ronaldch','12018777','ronald1.cheng@intel.com',4,0),(40,'Sabine Cox','sabinecx','11895483','sabinex.sandron@intel.com',10,0),(41,'Scott Howell','sdhowell','10629015','scott.howell@intel.com',8,0),(42,'Shane Kelly','sdkelly','10573443','shane.d.kelly@intel.com',8,0),(43,'Soni Vivek Govind','sgovind','12080257','soni.vivek.govind@intel.com',7,0),(44,'Prachi Shah','shahprac','12051718','prachi.shah@intel.com',8,0),(45,'Shane Chen','shaneche','11841791','shane.chen@intel.com',5,0),(46,'Sergey Lobachev','slobache','11448477','sergey.lobachev@intel.com',4,0),(47,'Thelfa Ali','tfali','10633119','thelfa.f.ali@intel.com',10,0),(48,'Kim Wai Toh','tkimwai','11055748','kim.wai.toh@intel.com',3,0),(49,'Page Wu','wupage','12108582','page.wu@intel.com',5,0),(50,'Yun Wang','yunwang1','12076536','yun.wang@intel.com',7,0),(51,'Zachari Higgins','zhigginx','12054556','zacharix.higgins@intel.com',1,1),(52,'Zachary Kvick','zkvick','11411459','zachary.n.kvick@intel.com',8,0),(53,'Sebastian Zych','zychseba','12111297','sebastian.zych@intel.com',10,0),(54,'Wei-Cheng Chen','weichen1','12143844','wei-cheng.chen@intel.com',5,0),(55,'Alexey Kulakov','alexeyku','11577019','alexey.kulakov@intel.com',5,0),(56,'James Thorburn','jthorbur','11254302','james.thorburn@intel.com',13,0),(57,'Robert Ornstein','rornstex','11828420','robertx.ornstein@intel.com',2,0),(58,'Mario Castro','mcast4x','11253949','mariox.castro@intel.com',2,0),(59,'Ille Covei','icoveix','12024896','iliex.covei@intel.com',2,0),(60,'Jesus Mendoza','jesusi2x','12173998','jesusx.isaac.mendoza.martinez@intel.com',11,0),(61,'Steven Huang','huangste','11905718','steven.huang@intel.com',5,0),(62,'Ilya Trishin','itrishin','11302350','ilya.trishin@intel.com',3,0),(64,'Luis Garcia','lrgarcia','10066167','luis.r.garcia@intel.com',1,0),(65,'Michael Alvarez','mcalvare','10062470','michael.c.alvarez@intel.com',12,0),(66,'Mathew Eszenyi','mseszeny','10765270','mathew.eszenyi@intel.com',12,0),(67,'Stephen Do','dosteph','11456732','stephen.do@intel.com',14,0),(68,'Moshe Eliahu','meliahu','10656710','moshe.eliahu@intel.com',15,0),(69,'Karen Gutierrez Cruz','kgutier','11564631','karen.f.gutierrez.cruz@intel.com',8,0),(70,'Claudio Glickman','claudiog','10658978','claudio.glickman@intel.com',15,0),(71,'Harish V','hvilava','11362430','harish.vilavankattil.mohan@intel.com',9,0);
/*!40000 ALTER TABLE `remote_lab_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-10 13:54:25
